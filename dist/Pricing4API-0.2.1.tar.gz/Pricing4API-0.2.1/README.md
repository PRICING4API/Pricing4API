# Pricing4Api
Python library for calculating properties related to Pricings
